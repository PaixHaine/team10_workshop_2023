-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Apr 07, 2023 at 12:02 PM
-- Server version: 5.7.39
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laraveldb`
--
CREATE DATABASE IF NOT EXISTS `laraveldb` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `laraveldb`;

-- --------------------------------------------------------

--
-- Table structure for table `actions`
--

CREATE TABLE `actions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `contact_id` bigint(20) UNSIGNED NOT NULL,
  `type` enum('email','call','appointment','todo') COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `date_rdv` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `actions`
--

INSERT INTO `actions` (`id`, `contact_id`, `type`, `notes`, `created_at`, `updated_at`, `date_rdv`) VALUES
(1, 5, 'appointment', 'dededed', '2023-04-03 15:01:19', '2023-04-03 15:01:19', '2023-04-08 18:52:00'),
(2, 5, 'email', 'zdzdz', '2023-04-03 15:11:56', '2023-04-03 15:11:56', NULL),
(6, 4, 'email', 'Test', '2023-04-04 10:42:29', '2023-04-04 10:42:29', NULL),
(21, 2, 'todo', 'vgbhn,', '2023-04-05 10:15:38', '2023-04-05 10:15:38', NULL),
(22, 4, 'todo', 'zsedrftgyhujkl', '2023-04-05 10:18:42', '2023-04-05 10:18:42', NULL),
(25, 2, 'email', 'TEST', '2023-04-05 21:14:00', '2023-04-05 21:14:00', NULL),
(27, 2, 'todo', 'zzdzd', '2023-04-05 21:56:18', '2023-04-05 21:56:18', NULL),
(28, 2, 'todo', 'V2', '2023-04-05 21:57:46', '2023-04-05 21:57:46', NULL),
(29, 6, 'todo', 'Test', '2023-04-05 21:59:39', '2023-04-05 21:59:39', NULL),
(32, 6, 'todo', 'Je suis Hermione', '2023-04-06 09:11:35', '2023-04-06 09:11:35', NULL),
(34, 2, 'appointment', 'Rdv medecin', '2023-04-06 09:21:02', '2023-04-06 09:21:02', '2023-04-22 13:18:00'),
(36, 2, 'email', 'Test envoi', '2023-04-06 09:22:20', '2023-04-06 09:22:20', NULL),
(38, 5, 'appointment', 'Rappel acheter du lait', '2023-04-06 10:13:40', '2023-04-06 10:13:40', '2023-04-21 14:13:00'),
(39, 6, 'todo', 'Acheter du pain', '2023-04-06 10:16:08', '2023-04-06 10:16:08', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('b2b','b2c') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('in_progress','dead') COLLATE utf8mb4_unicode_ci NOT NULL,
  `genre` enum('lead','prospect','client') COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_interested` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `todo_count` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `firstName`, `email`, `phone`, `type`, `status`, `genre`, `is_interested`, `is_active`, `created_at`, `updated_at`, `todo_count`) VALUES
(2, 'Potter', 'Harry', 'potter@gmail.com', '0643850357', 'b2b', 'dead', 'lead', 0, 1, '2023-03-30 16:35:12', '2023-04-06 09:18:20', 0),
(4, 'Weasley', 'Ronald', 'ron@gmail.com', '0708090603', 'b2c', 'dead', 'lead', 0, 1, '2023-03-31 09:17:33', '2023-04-06 09:11:53', 0),
(5, 'Weasley', 'Ginny', 'ginny@hogwarts.com', '0643850357', 'b2b', 'in_progress', 'prospect', 0, 1, '2023-03-31 22:40:06', '2023-03-31 22:40:06', 0),
(6, 'Granger', 'Hermione', 'hermione@gmail.com', '0102030405', 'b2c', 'in_progress', 'client', 0, 1, '2023-04-05 21:34:45', '2023-04-05 21:34:45', 0),
(8, 'Hagrid', 'Professeur', 'hagrid@gmail.com', '0101010101', 'b2c', 'in_progress', 'client', 0, 1, '2023-04-06 10:12:10', '2023-04-06 10:12:10', 0);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2014_10_12_100000_create_password_resets_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2023_03_30_083434_create_leads_table', 2),
(7, '2023_03_30_083447_create_prospects_table', 2),
(8, '2023_03_30_083454_create_clients_table', 2),
(10, '2023_03_30_130708_changement_colonnes_leads', 3),
(12, '2023_03_30_132337_lead_ajout_statut_type', 4),
(14, '2023_03_30_165831_create_contacts_table', 5),
(19, '2023_04_03_132242_action', 6),
(20, '2023_04_03_134229_insert_daterdv', 6),
(21, '2023_04_03_163621_create_actions_table', 7),
(22, '2023_04_03_165527_addrdv', 8),
(23, '2023_04_04_130209_create_todos_table', 9),
(24, '2023_04_04_130940_add_todo_to_contact', 10),
(25, '2023_04_05_104048_modify_actions_table', 11);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_reset_tokens`
--

INSERT INTO `password_reset_tokens` (`email`, `token`, `created_at`) VALUES
('test@gmail.com', '$2y$10$TbO8/uh47lbrrqQeWVh5z.o3CxG0fvzvvOMMO1nPbCxBSi6r45wKu', '2023-03-31 21:24:23');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `todos`
--

CREATE TABLE `todos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `contact_id` bigint(20) UNSIGNED NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `done` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `todos`
--

INSERT INTO `todos` (`id`, `contact_id`, `content`, `done`, `created_at`, `updated_at`) VALUES
(14, 2, 'Mon nom est Harry', 0, '2023-04-06 09:10:54', '2023-04-06 09:10:54'),
(15, 4, 'Mon nom est Ron', 0, '2023-04-06 09:11:05', '2023-04-06 09:56:00'),
(16, 6, 'Je suis Hermione', 1, '2023-04-06 09:11:15', '2023-04-06 09:11:35'),
(17, 5, 'Hermione est mon amie', 0, '2023-04-06 09:11:31', '2023-04-06 09:11:31'),
(18, 6, 'Acheter du pain', 1, '2023-04-06 10:15:56', '2023-04-06 10:16:08');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(5, 'AdminConnectify', 'admin@connectify.com', NULL, '$2y$10$7U6h3cl0ZAM81JeX7c5.quzWEDu5qEqkIxh7G096BnAyQ.vRWdUUS', NULL, '2023-03-31 21:30:09', '2023-04-07 10:01:40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `actions`
--
ALTER TABLE `actions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `actions_contact_id_foreign` (`contact_id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `todos`
--
ALTER TABLE `todos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `todos_contact_id_foreign` (`contact_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `actions`
--
ALTER TABLE `actions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `todos`
--
ALTER TABLE `todos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `actions`
--
ALTER TABLE `actions`
  ADD CONSTRAINT `actions_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `todos`
--
ALTER TABLE `todos`
  ADD CONSTRAINT `todos_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
