<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="gabDashboard">
        <h1>Tableau de bord</h1>
        <div class="widgets">
            <div class="row gap-5">
                <script>
                    window.chartData = <?php echo json_encode($chartData, 15, 512) ?>;
                    window.chartActionsData = <?php echo json_encode($chartActionsData, 15, 512) ?>;
                </script>
                <div class="cam col-4 rounded-5 bg-white p-3">
                    <h3 class="text-center">Nombre de contact(s)</h3>
                    <canvas id="contacts-chart" width="100" height="100"></canvas>
                </div>
                <div class="cam col-4 rounded-5 bg-white p-3">
                    <h3 class="text-center">Actions réalisée(s)</h3>
                    <canvas id="actions-chart" width="50" height="100"></canvas>
                </div>
            </div>
            <div class="row mt-4">
                <div class="boxTodo col-12 rounded-5 bg-white p-3" style="position: relative; left: 0px; top: 0px;">
                    <div class="ui-sortable-handle">
                        <h3 class="title text-center">
                            <i class="ion ion-clipboard mr-1"></i>
                            Liste To Do
                        </h3>
                    </div>
                    <ul class="todoList todo-list ui-sortable" data-widget="todo-list">
                        <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="bg-white mt-4">
                                <span>Pour <?php echo e($todo->contact->firstName); ?></span>
                                <div class="tools d-inline-block float-right">
                                    <form action="<?php echo e(route('contacts.destroyTodo', $todo->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn delete"><i class="fas fa-trash mr-2"></i>Supprimer</button>
                                    </form>
                                </div>
                                <div class="icheck-primary d-flex mt-4">
                                    <form action="<?php echo e(route('todos.markDone', $todo->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="_method" value="POST">
                                        <input type="hidden" name="isCompleted" value="<?php echo e($todo->done ? '0' : '1'); ?>">
                                        <?php if($todo->done): ?>
                                            <span class="realisee rounded-3 px-2 py-1 mr-2"><i class="fas fa-check-circle mr-1"></i>Réalisée</span>
                                        <?php elseif(!$todo->done): ?>
                                            <span class="nonRealisee rounded-3 px-2 py-1 mr-2"><i class="fas fa-user-clock mr-1"></i>En cours</span>
                                        <?php endif; ?>

                                        <input class="boxCheck" type="checkbox" value="<?php echo e($todo->id); ?>" name="todo<?php echo e($todo->id); ?>" id="todoCheck<?php echo e($todo->id); ?>" <?php echo e($todo->done ? 'checked' : ''); ?>>
                                        <span class="text ml-2"><?php echo e($todo->content); ?></span>
                                        <small class="badge retour ml-2" ><i class="far fa-clock"></i> <?php echo e($todo->created_at->diffForHumans()); ?></small>
                                    </form>
                                </div>

                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="footer clearfix">
                        <button type="button" class="btn send mb-3 float-right" id="add-todo-btn"><i class="fas fa-plus"></i> Ajouter une tâche</button>
                    </div>

                    <form method="POST" action="<?php echo e(route('contacts.storeTodo')); ?>" id="add-todo-form" style="display: none;" class="p-3">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="contact">Pour qui ?</label>
                            <select name="contact_id" id="contact" class="form-control">
                                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($contact->id); ?>"><?php echo e($contact->firstName . ' ' . $contact->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="content">Contenu</label>
                            <textarea name="content" id="content" class="form-control"></textarea>
                        </div>
                        <button type="submit" class="btn send d-block ml-auto"><i class="fas fa-plus-circle mr-2"></i>Créer</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <?php $__env->startPush('js'); ?>
        <script>
            $(document).ready(function() {
                $('#add-todo-btn').click(function() {
                    $('#add-todo-form').toggle();
                });
            });

            window.addEventListener('load', function() {
                var checkboxes = document.querySelectorAll('input[type="checkbox"]');

                checkboxes.forEach(function(checkbox) {
                    checkbox.addEventListener('change', function() {
                        this.form.submit();
                    });
                });
            });

        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/team10_workshop_2023/www/resources/views/home.blade.php ENDPATH**/ ?>